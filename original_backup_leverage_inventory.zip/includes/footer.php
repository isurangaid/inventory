
<footer class="footer mt-auto py-3 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <span class="text-muted">IT Equipment Tracker &copy; <?php echo date('Y'); ?></span>
            </div>
            <div class="col-md-6 text-md-end">
                <span class="text-muted">v1.0.0</span>
            </div>
        </div>
    </div>
</footer>