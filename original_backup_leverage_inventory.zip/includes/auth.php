<?php
// includes/auth.php
if (!defined('ROOT_PATH')) {
    require_once __DIR__ . '/config.php';
}

function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function is_admin() {
    return is_logged_in() && $_SESSION['user_level'] === 'admin';
}

function login($username, $password, $conn) {
    $username = $conn->real_escape_string(trim($username));
    $password = trim($password);
    
    if (empty($username) || empty($password)) {
        return ['status' => 'error', 'message' => 'Username and password are required'];
    }

    $sql = "SELECT user_id, username, password, full_name, user_level 
            FROM users 
            WHERE username = '$username' AND is_active = 1 
            LIMIT 1";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['user_level'] = $user['user_level'];
            $_SESSION['last_activity'] = time();
            
            // Log this login
            $log_sql = "INSERT INTO audit_log (user_id, action, table_affected, record_id, action_details, ip_address,created_at) 
                         VALUES ('{$user['user_id']}', 'Login', 'users', '{$user['user_id']}', 'User logged in', '{$_SERVER['REMOTE_ADDR']}','".date('Y-m-d H:i:s')."')";
            $conn->query($log_sql);
            
            return ['status' => 'success'];
        }
    }
    
    // Log failed attempt
    $log_sql = "INSERT INTO audit_log (user_id, action, table_affected, record_id, action_details, ip_address,created_at) 
                VALUES (NULL, 'Failed Login', 'users', NULL, 'Failed login attempt for: $username', '{$_SERVER['REMOTE_ADDR']}','".date('Y-m-d H:i:s')."')";
    $conn->query($log_sql);
    
    return ['status' => 'error', 'message' => 'Invalid credentials'];
}

function logout($conn) {
    if (is_logged_in()) {
        // Log the logout
        $log_sql = "INSERT INTO audit_log (user_id, action, table_affected, record_id, action_details, ip_address,created_at) 
                    VALUES ('{$_SESSION['user_id']}', 'Logout', 'users', '{$_SESSION['user_id']}', 'User logged out', '{$_SERVER['REMOTE_ADDR']}','".date('Y-m-d H:i:s')."')";
        $conn->query($log_sql);
        
        $_SESSION = array();
        session_destroy();
    }
    header("Location: auth/login.php");
    exit();
}

function require_login() {
    if (!is_logged_in()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header("Location: auth/login.php");
        exit();
    }
    $_SESSION['last_activity'] = time();
}

// Check for inactive session (30 minute timeout)
if (is_logged_in() && (time() - $_SESSION['last_activity'] > 1800)) {
    $log_sql = "INSERT INTO audit_log (user_id, action, table_affected, record_id, action_details, ip_address,created_at) 
                VALUES ('{$_SESSION['user_id']}', 'Session Timeout', 'users', '{$_SESSION['user_id']}', 'Session expired due to inactivity', '{$_SERVER['REMOTE_ADDR']}','".date('Y-m-d H:i:s')."')";
    $GLOBALS['conn']->query($log_sql);
    
    logout($GLOBALS['conn']);
}