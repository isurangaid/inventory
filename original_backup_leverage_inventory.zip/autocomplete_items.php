<?php
require_once __DIR__ . '/includes/config.php';

$term = isset($_GET['term']) ? $conn->real_escape_string($_GET['term']) : '';
$suggestions = [];

if ($term !== '') {
    $query = "SELECT DISTINCT name FROM items WHERE name LIKE '%$term%' ORDER BY name LIMIT 10";
    $result = $conn->query($query);

    while ($row = $result->fetch_assoc()) {
        $suggestions[] = $row['name'];
    }
}

echo json_encode($suggestions);
