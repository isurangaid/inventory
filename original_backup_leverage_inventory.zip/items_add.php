<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

// Get dropdown options
$categories = $locations = $suppliers = [];

$result = $conn->query("SELECT * FROM category ORDER BY name");
if ($result) while ($row = $result->fetch_assoc()) $categories[] = $row;

$result = $conn->query("SELECT * FROM locations ORDER BY name");
if ($result) while ($row = $result->fetch_assoc()) $locations[] = $row;

$result = $conn->query("SELECT * FROM suppliers ORDER BY name");
if ($result) while ($row = $result->fetch_assoc()) $suppliers[] = $row;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $asset_id = $conn->real_escape_string($_POST['asset_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $serial_number = $conn->real_escape_string($_POST['serial_number']);
    $model = $conn->real_escape_string($_POST['model']);
    $category_id = (int)$_POST['category_id'];
    $sub_category_id = (int)$_POST['sub_category_id'];
    $supplier_id = (int)$_POST['supplier_id'];
    $location_id = (int)$_POST['location_id'];
    $status = $conn->real_escape_string($_POST['status']);
    $purchase_date = $conn->real_escape_string($_POST['purchase_date']);
    $warranty_months = (int)$_POST['warranty_months'];
    $notes = $conn->real_escape_string($_POST['notes']);
    
    // Calculate warranty end date
    $warranty_end = '';
    if ($purchase_date && $warranty_months > 0) {
        $warranty_end = date('Y-m-d', strtotime($purchase_date . " + $warranty_months months"));
    }
    
    $sql = "INSERT INTO items (
                asset_id, name, serial_number, model, 
                category_id, sub_category_id, supplier_id, location_id,
                status, purchase_date, warranty_months, warranty_end, notes
            ) VALUES (
                '$asset_id', '$name', '$serial_number', '$model',
                $category_id, $sub_category_id, $supplier_id, $location_id,
                '$status', '$purchase_date', $warranty_months, " . ($warranty_end ? "'$warranty_end'" : "NULL") . ", '$notes'
            )";
    
    if ($conn->query($sql)) {
        $item_id = $conn->insert_id;
        
        // Log the action
        $conn->query("INSERT INTO audit_log (
            user_id, action, table_affected, record_id, action_details, ip_address, created_at
        ) VALUES (
            '{$_SESSION['user_id']}', 'Create', 'items', '$item_id', 
            'Added new equipment: $asset_id', '{$_SERVER['REMOTE_ADDR']}','".date('Y-m-d H:i:s')."'
        )");

        $audit_log_id = $conn->insert_id;
        // Item history tracking
        $description = "Asset ID - ".$asset_id." (".$name.") has been added to the system. | by ".$_SESSION['full_name'];
        $conn->query("INSERT INTO item_history (`item_id`, `user_id`, `action`, `description`,`audit_log_id`) VALUES (
            '$item_id', '{$_SESSION['user_id']}', 'New asset add', '$description','$audit_log_id'
        )");
        
        $_SESSION['message'] = "Equipment added successfully";
        header("Location: items.php");
        exit();
    } else {
        $error = "Error adding equipment: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Equipment | IT Tracker</title>
    <?php include __DIR__ . '/includes/header_scripts.php'; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        .subcategory-loading {
            display: none;
            color: #6c757d;
            font-style: italic;
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>
    <div class="container-fluid flex-grow-1">
        <div class="row">
            <?php include __DIR__ . '/includes/sidebar.php'; ?>
    
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1 class="h2">Add New Equipment</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="items.php" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-arrow-left"></i> Back to List
                        </a>
                    </div>
                </div>

                <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-body">
                        <form method="POST" id="equipmentForm">
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="asset_id" class="form-label">Asset ID*</label>
                                    <input type="text" class="form-control" id="asset_id" name="asset_id">
                                    <small class="text-muted">Unique identifier for this equipment</small>
                                </div>
                                <div class="col-md-6">
                                    <label for="name" class="form-label">Equipment Name*</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="serial_number" class="form-label">Serial Number</label>
                                    <input type="text" class="form-control" id="serial_number" name="serial_number">
                                </div>
                                <div class="col-md-6">
                                    <label for="model" class="form-label">Model</label>
                                    <input type="text" class="form-control" id="model" name="model">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label for="category_id" class="form-label">Category*</label>
                                    <select class="form-select" id="category_id" name="category_id" required>
                                        <option value="">Select Category</option>
                                        <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['category_id']; ?>">
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="sub_category_id" class="form-label">Sub-Category</label>
                                    <select class="form-select" id="sub_category_id" name="sub_category_id">
                                        <option value="0">Select Category First</option>
                                    </select>
                                    <div id="subcategoryLoading" class="subcategory-loading">Loading subcategories...</div>
                                </div>
                                <div class="col-md-4">
                                    <label for="supplier_id" class="form-label">Supplier</label>
                                    <select class="form-select" id="supplier_id" name="supplier_id">
                                        <option value="">Select Supplier</option>
                                        <?php foreach ($suppliers as $supplier): ?>
                                        <option value="<?php echo $supplier['supplier_id']; ?>">
                                            <?php echo htmlspecialchars($supplier['name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label for="location_id" class="form-label">Location*</label>
                                    <select class="form-select" id="location_id" name="location_id" required>
                                        <option value="">Select Location</option>
                                        <?php foreach ($locations as $location): ?>
                                        <option value="<?php echo $location['location_id']; ?>">
                                            <?php echo htmlspecialchars($location['name']); ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="status" class="form-label">Status*</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="1">Working</option>
                                        <option value="2">Under Repair</option>
                                        <option value="3">Out of Service</option>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="purchase_date" class="form-label">Purchase Date</label>
                                    <input type="date" class="form-control" id="purchase_date" name="purchase_date">
                                </div>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="warranty_months" class="form-label">Warranty (months)</label>
                                    <input type="number" class="form-control" id="warranty_months" name="warranty_months" min="0">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="notes" class="form-label">Notes</label>
                                <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Save Equipment</button>
                        </form>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <?php include __DIR__ . '/includes/footer.php'; ?>
    <?php include __DIR__ . '/includes/footer_scripts.php'; ?>
    
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
    $(function() {
        $('#name').autocomplete({
            source: function(request, response) {
                $.ajax({
                    url: 'autocomplete_items.php',
                    dataType: 'json',
                    data: { term: request.term },
                    success: function(data) {
                        response(data);
                    }
                });
            },
            minLength: 2,
            select: function(event, ui) {
                $('#name').val(ui.item.value);
                return false;
            }
        });
    });
    // Initialize date picker
    flatpickr("#purchase_date", {
        dateFormat: "Y-m-d",
        allowInput: true
    });

    // AJAX-based sub-category loading
    document.addEventListener('DOMContentLoaded', function() {
        const categorySelect = document.getElementById('category_id');
        const subcategorySelect = document.getElementById('sub_category_id');
        const loadingIndicator = document.getElementById('subcategoryLoading');
        
        categorySelect.addEventListener('change', function() {
            const categoryId = this.value;
            
            // Reset subcategory dropdown
            subcategorySelect.innerHTML = '<option value="0">Loading sub-categories...</option>';
            subcategorySelect.disabled = true;
            loadingIndicator.style.display = 'block';
            
            if (!categoryId) {
                subcategorySelect.innerHTML = '<option value="0">Select a category first</option>';
                subcategorySelect.disabled = false;
                loadingIndicator.style.display = 'none';
                return;
            }
            
            // Make AJAX request to get sub-categories
            fetch('get_subcategories.php?category_id=' + categoryId)
                .then(response => response.json())
                .then(data => {
                    subcategorySelect.innerHTML = '<option value="0">Select Sub-Category</option>';
                    
                    if (data.length > 0) {
                        data.forEach(subcat => {
                            const option = new Option(subcat.name, subcat.sub_category_id);
                            subcategorySelect.add(option);
                        });
                    } else {
                        subcategorySelect.innerHTML = '<option value="0">No sub-categories found</option>';
                    }
                    
                    subcategorySelect.disabled = false;
                    loadingIndicator.style.display = 'none';
                })
                .catch(error => {
                    console.error('Error loading sub-categories:', error);
                    subcategorySelect.innerHTML = '<option value="0">Error loading sub-categories</option>';
                    subcategorySelect.disabled = false;
                    loadingIndicator.style.display = 'none';
                });
        });
        
        // Trigger change if category already selected (after form validation error)
        if (categorySelect.value) {
            categorySelect.dispatchEvent(new Event('change'));
        }
    });
    </script>
</body>
</html>