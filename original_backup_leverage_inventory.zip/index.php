<?php 
header("Location:auth/index.php");
?>